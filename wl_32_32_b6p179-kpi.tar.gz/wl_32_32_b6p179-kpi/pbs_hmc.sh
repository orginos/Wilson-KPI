#!/bin/bash
#PBS -N qtop
#PBS -l nodes=16:ppn=24 -l walltime=48:00:00

export LD_LIBRARY_PATH=/shared/gcc-5.3.0/lib64:/shared/gcc-5.3.0/lib
export PATH=/shared/openmpi-1.10.1/gcc-5.3.0/bin:/shared/gcc-5.3.0/bin:$PATH
export OMP_NUM_THREADS=12

BETA=b6p179

JOB_LABEL=wl_32_32_${BETA}

# The job script for resubmission
JOB_SCRIPT=hmc_${BETA}.sh

cd $PBS_O_WORKDIR


CHROMA=./exe/hmc

export NODEFILE=pbs.out/nodes.$PBS_JOBID
cat $PBS_NODEFILE | uniq | perl -ne 'print "$_" x2' > $NODEFILE

GEOM="1 2 4 4"
pushd ./cfgs
START_CFG=`ls ${JOB_LABEL}_restart_*.xml | cut -f1 -d'.' | cut -f6 -d'_' | sort -rn | head -1`
popd

/shared/openmpi-1.10.1/gcc-5.3.0/bin/mpirun -hostfile $NODEFILE --np 32  \
    $CHROMA  \
   -i ./cfgs/${JOB_LABEL}_restart_${START_CFG}.xml \
   -o ./xml.out/${JOB_LABEL}.${START_CFG}.hmc.out.xml \
   -l ./xml.log/${JOB_LABEL}.${START_CFG}.hmc.log.xml \
   -geom $GEOM  2>&1  | tee ./pbs.out/${JOB_LABEL}.${START_CFG}.hmc.stdout 

ssh cyclops<<EOF 
cd $PBS_O_WORKDIR
qsub pbs_hmc.sh
EOF


